package com.luv2code.springboot.thymeleafdemo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloWorldController {

    // show the form
    @RequestMapping("/showForm")
    public String showForm() {
        return "helloworld-form";
    }

    // process the form
    @RequestMapping("/processForm")
    public String processForm(
            @RequestParam("studentName") String theName,
            @RequestParam("favoriteSport") String theSport,
            Model model) {

        // add data to the model
        model.addAttribute("message", "Your Name: " + theName);
        model.addAttribute("sportMessage", "Favorite Sport: " + theSport);

        return "helloworld";
    }
}
