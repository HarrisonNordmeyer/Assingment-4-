package com.luv2code.springboot.demo.mycoolapp.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FunRestController {

    // expose "/" that return "Hello World"

    @GetMapping("/")
    public String sayHello() {
        return "my name is Harrison";
    }

    // expose a new endpoint for "workout"

    @GetMapping("/favorite movie,")
    public String getDailyWorkout() {
        return "my fav movie is die hard";
    }

    // expose a new endpoint for "fortune"

    @GetMapping("/sport")
    public String getDailyFortune() {
        return "my fav sport is rugby";
    }

}






