package com.luv2code.springcoredemo;

import org.springframework.stereotype.Component;

@Component
public class CricketCoach implements Coach {
    @Override
    public String basketball() {
        return "Practice fast bowling for 15 minutes";
    }
}
